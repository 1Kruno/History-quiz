﻿Module Module1
    Public user As String
    Public numbers = New Integer() {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
    Public question = New String() {"Prefix for country Russia is:", "45+89+65+342-14-1+3=?", "Region Lombardy is located where?", "What was the nickname of the famous german pilot in WW1?", "When was the Irish uprising?", "What is the name of this animal?", "Which country has the smallest population?", "Which ethno-linguistic group does this gentleman belong to?", "Which audio program was popular in the late 90s?", "How many wars are the USA currently fighting at the moment?"}
    Public answera = New String() {"A)Mother", "A)485", "A)Spain", "A)Black death", "A)1917", "A)Mouse", "A)Andora", "A)Turkish", "A)iTunes", "A)2"}
    Public answerb = New String() {"B)Father", "B)621", "B)Italy", "B)Red baron", "B)1985", "B)Weasel", "B)Vatican", "B)Slavic", "B)Winamp", "B)4"}
    Public answerc = New String() {"C)Uncle", "C)529", "C)France", "C)Blue ghost", "C)1916", "C)Elephant", "C)Malta", "C)German", "C)Black player", "C)6"}
    Public answerd = New String() {"D)Aunt", "D)493", "D)Wales", "D)Krauter", "D)6 A.D", "D)Wombat", "D)Montenegro", "D)Finno-Ugric", "D)Swamp", "D)0"}
    Public correct_answer = New String() {"A", "C", "B", "B", "C", "D", "B", "B", "B", "C"}
    Public answer_selected As String
    Public accumulator1 As Byte
    Public score As Byte
    Public counter As Byte
    Public correct_A As String
    Public Q_count As Byte

    Public number1 As Single
    Public number2 As Single
    Public number3 As Single
    Public number4 As Single
    Public number5 As Single
    Public number6 As Single
    Public number7 As Single
    Public number8 As Single
    Public number9 As Single
    Public number0 As Single
    Public arritmethicproccess As String
    Public aoperator As Integer


    

End Module
