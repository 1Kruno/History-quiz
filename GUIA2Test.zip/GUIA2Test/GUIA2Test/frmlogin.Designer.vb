﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmlogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmlogin))
        Me.cmbusers = New System.Windows.Forms.ComboBox
        Me.txtpassword = New System.Windows.Forms.TextBox
        Me.lblpassword = New System.Windows.Forms.Label
        Me.cmdlogin = New System.Windows.Forms.Button
        Me.cmdexit = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.cmdhelp = New System.Windows.Forms.Button
        Me.red = New System.Windows.Forms.CheckBox
        Me.blue = New System.Windows.Forms.CheckBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbusers
        '
        Me.cmbusers.FormattingEnabled = True
        Me.cmbusers.Location = New System.Drawing.Point(151, 144)
        Me.cmbusers.Name = "cmbusers"
        Me.cmbusers.Size = New System.Drawing.Size(195, 21)
        Me.cmbusers.TabIndex = 0
        Me.cmbusers.Text = "Select a username"
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(151, 171)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtpassword.Size = New System.Drawing.Size(195, 20)
        Me.txtpassword.TabIndex = 1
        Me.txtpassword.Tag = ""
        '
        'lblpassword
        '
        Me.lblpassword.AutoSize = True
        Me.lblpassword.Location = New System.Drawing.Point(206, 194)
        Me.lblpassword.Name = "lblpassword"
        Me.lblpassword.Size = New System.Drawing.Size(90, 13)
        Me.lblpassword.TabIndex = 2
        Me.lblpassword.Text = "Type in password"
        '
        'cmdlogin
        '
        Me.cmdlogin.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.cmdlogin.Location = New System.Drawing.Point(175, 234)
        Me.cmdlogin.Name = "cmdlogin"
        Me.cmdlogin.Size = New System.Drawing.Size(149, 46)
        Me.cmdlogin.TabIndex = 3
        Me.cmdlogin.Text = "&Login"
        Me.cmdlogin.UseVisualStyleBackColor = False
        '
        'cmdexit
        '
        Me.cmdexit.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.cmdexit.Location = New System.Drawing.Point(175, 286)
        Me.cmdexit.Name = "cmdexit"
        Me.cmdexit.Size = New System.Drawing.Size(149, 45)
        Me.cmdexit.TabIndex = 4
        Me.cmdexit.Text = "&Exit"
        Me.cmdexit.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(473, 117)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'cmdhelp
        '
        Me.cmdhelp.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.cmdhelp.Location = New System.Drawing.Point(377, 448)
        Me.cmdhelp.Name = "cmdhelp"
        Me.cmdhelp.Size = New System.Drawing.Size(89, 34)
        Me.cmdhelp.TabIndex = 6
        Me.cmdhelp.Text = "&Help"
        Me.cmdhelp.UseVisualStyleBackColor = False
        '
        'red
        '
        Me.red.AutoSize = True
        Me.red.Location = New System.Drawing.Point(42, 412)
        Me.red.Name = "red"
        Me.red.Size = New System.Drawing.Size(125, 17)
        Me.red.TabIndex = 7
        Me.red.Text = "Change colour to red"
        Me.red.UseVisualStyleBackColor = True
        '
        'blue
        '
        Me.blue.AutoSize = True
        Me.blue.Location = New System.Drawing.Point(42, 435)
        Me.blue.Name = "blue"
        Me.blue.Size = New System.Drawing.Size(130, 17)
        Me.blue.TabIndex = 8
        Me.blue.Text = "Change colour to blue"
        Me.blue.UseVisualStyleBackColor = True
        '
        'frmlogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(478, 494)
        Me.Controls.Add(Me.blue)
        Me.Controls.Add(Me.red)
        Me.Controls.Add(Me.cmdhelp)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cmdexit)
        Me.Controls.Add(Me.cmdlogin)
        Me.Controls.Add(Me.lblpassword)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.cmbusers)
        Me.Name = "frmlogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmlogin"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbusers As System.Windows.Forms.ComboBox
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
    Friend WithEvents lblpassword As System.Windows.Forms.Label
    Friend WithEvents cmdlogin As System.Windows.Forms.Button
    Friend WithEvents cmdexit As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents cmdhelp As System.Windows.Forms.Button
    Friend WithEvents red As System.Windows.Forms.CheckBox
    Friend WithEvents blue As System.Windows.Forms.CheckBox
End Class
