﻿Public Class frmresult
    'this form will offer the user to see his statistics'
    'user can see the time he took to finish the test'
    'user will be able to see how many questions he got wrong'
    'user will be presented with appropriate picture based on result'
    Private Sub cmdshowresult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdshowresult.Click
        On Error Resume Next
        txtresult.Text = "Your score " & score
        If score >= 6 Then
            Picturegood.Visible = True
        ElseIf score <= 4 Then
            Picturebad.Visible = True
        ElseIf score = 5 Then
            Pictureneutral.Visible = True
        End If

        txttime.Text = "You took " & (200 - accumulator1) & " seconds to complete the quiz!"


    End Sub

    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        On Error Resume Next
        Me.Close()

    End Sub

    Private Sub cmdhelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhelp.Click
        On Error Resume Next
        frmhelp.Show()

    End Sub

    Private Sub frmresult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class