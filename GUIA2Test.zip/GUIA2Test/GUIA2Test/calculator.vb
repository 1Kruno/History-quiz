﻿'in this form, user will be able to use calculator'
'this form allows user to divide, multiply, deduct, add, calculate square root, remember value and load remembered value'
'user can also use decimal point'
'program is preventing user from placing more than 1 decimal point'
Option Explicit On

Public Class calculator
    Public user As VariantType
    Public number1 As Decimal
    Public number2 As Decimal
    Public number3 As Decimal
    Public number4 As Decimal
    Public number5 As Decimal
    Public number6 As Decimal
    Public number7 As Decimal
    Public number8 As Decimal
    Public number9 As Decimal
    Public number0 As Decimal
    Dim M = 0
    Public answer As Single
    Public arithmeticprocess As Single
    Public aoperator As Integer

  

    Private Sub calculator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
       
    End Sub
    
    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "1"
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "2"
    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "3"
    End Sub

    Private Sub btn4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "4"
    End Sub

    Private Sub btn5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "5"
    End Sub

    Private Sub btn6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn6.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "6"
    End Sub

    Private Sub btn7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn7.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "7"
    End Sub

    Private Sub btn8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn8.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "8"
    End Sub

    Private Sub btn9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn9.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "9"
    End Sub

    Private Sub btn0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn0.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "0"
    End Sub

    Private Sub cmddot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmddot.Click
        On Error Resume Next
        Label1.Text = ""
        txtdisplay.Text = txtdisplay.Text & "."
        If UBound(Split(txtdisplay.Text, ".", -1, vbTextCompare)) > 1 Then MsgBox("Too many decimals points ")
    End Sub

    Private Sub cmdplus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdplus.Click
        On Error Resume Next
        number1 = txtdisplay.Text
        aoperator = 1
        txtdisplay.Text = ""
    End Sub

    Private Sub cmdclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdclear.Click
        On Error Resume Next
        txtdisplay.Text = ""
        Label1.Text = ""
        txtresult.Text = ""
    End Sub

    Private Sub cmdequals_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdequals.Click
        On Error Resume Next
        number2 = txtdisplay.Text
        txtdisplay.Text = ""
        txtresult.Text = answer
        If aoperator = 1 Then
            answer = number1 + number2
            txtdisplay.Text = ""
            txtresult.Text = answer
        End If

        If aoperator = 2 Then
            answer = number1 * number2
            txtdisplay.Text = ""
            txtresult.Text = answer
        End If
        If aoperator = 3 Then
            answer = number1 / number2
            txtdisplay.Text = ""
            txtresult.Text = answer
        End If
        If aoperator = 4 Then
            answer = number1 - number2
            txtdisplay.Text = ""
            txtresult.Text = answer
        End If
    End Sub

    Private Sub txtdisplay_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdisplay.TextChanged

    End Sub

    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        Me.Close()
        frmmenu.Show()

    End Sub

    Private Sub cmdminus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdminus.Click
        On Error Resume Next
        number1 = txtdisplay.Text
        aoperator = 4
        txtdisplay.Text = ""
    End Sub

    Private Sub cmdmultiply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmultiply.Click
        On Error Resume Next
        number1 = txtdisplay.Text
        aoperator = 2
        txtdisplay.Text = ""
    End Sub

    Private Sub cmddivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmddivide.Click
        On Error Resume Next
        number1 = txtdisplay.Text
        aoperator = 3
        txtdisplay.Text = ""
    End Sub

    Private Sub cmdhelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhelp.Click
        On Error Resume Next
        frmhelp.Show()

    End Sub

    Private Sub cmdsquare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdsquare.Click
        On Error Resume Next
        txtresult.Text = Math.Sqrt(Val(txtdisplay.Text))
    End Sub

   
    Private Sub cmdmplus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmplus.Click
        On Error Resume Next
        M = M + Val(txtresult.Text)
    End Sub

    Private Sub cmdmr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdmr.Click
        On Error Resume Next
        Me.txtresult.Text = (M)
    End Sub
End Class
