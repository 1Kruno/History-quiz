﻿Public Class frmhelp
    'this is a help menu'
    'user will get clarification for program functions here'
    'this menu is available on every form'
    'when finished reading, user can leave by pressing the "exit" button'
    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        On Error Resume Next
        Me.Close()

    End Sub

    Private Sub frmhelp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class