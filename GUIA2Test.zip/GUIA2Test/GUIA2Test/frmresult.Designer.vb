﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmresult
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmresult))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Picturegood = New System.Windows.Forms.PictureBox
        Me.Picturebad = New System.Windows.Forms.PictureBox
        Me.txtresult = New System.Windows.Forms.TextBox
        Me.txttime = New System.Windows.Forms.TextBox
        Me.cmdshowresult = New System.Windows.Forms.Button
        Me.cmdexit = New System.Windows.Forms.Button
        Me.lblscore = New System.Windows.Forms.Label
        Me.lbltimetaken = New System.Windows.Forms.Label
        Me.Pictureneutral = New System.Windows.Forms.PictureBox
        Me.cmdhelp = New System.Windows.Forms.Button
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Picturegood, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Picturebad, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pictureneutral, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(4, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(675, 175)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Picturegood
        '
        Me.Picturegood.Image = CType(resources.GetObject("Picturegood.Image"), System.Drawing.Image)
        Me.Picturegood.Location = New System.Drawing.Point(215, 206)
        Me.Picturegood.Name = "Picturegood"
        Me.Picturegood.Size = New System.Drawing.Size(242, 227)
        Me.Picturegood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Picturegood.TabIndex = 1
        Me.Picturegood.TabStop = False
        Me.Picturegood.Visible = False
        '
        'Picturebad
        '
        Me.Picturebad.Image = CType(resources.GetObject("Picturebad.Image"), System.Drawing.Image)
        Me.Picturebad.Location = New System.Drawing.Point(199, 229)
        Me.Picturebad.Name = "Picturebad"
        Me.Picturebad.Size = New System.Drawing.Size(268, 189)
        Me.Picturebad.TabIndex = 2
        Me.Picturebad.TabStop = False
        Me.Picturebad.Visible = False
        '
        'txtresult
        '
        Me.txtresult.Location = New System.Drawing.Point(92, 462)
        Me.txtresult.Name = "txtresult"
        Me.txtresult.Size = New System.Drawing.Size(223, 20)
        Me.txtresult.TabIndex = 3
        '
        'txttime
        '
        Me.txttime.Location = New System.Drawing.Point(354, 462)
        Me.txttime.Name = "txttime"
        Me.txttime.Size = New System.Drawing.Size(223, 20)
        Me.txttime.TabIndex = 4
        '
        'cmdshowresult
        '
        Me.cmdshowresult.Location = New System.Drawing.Point(270, 545)
        Me.cmdshowresult.Name = "cmdshowresult"
        Me.cmdshowresult.Size = New System.Drawing.Size(144, 30)
        Me.cmdshowresult.TabIndex = 5
        Me.cmdshowresult.Text = "&Show result"
        Me.cmdshowresult.UseVisualStyleBackColor = True
        '
        'cmdexit
        '
        Me.cmdexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdexit.Location = New System.Drawing.Point(270, 581)
        Me.cmdexit.Name = "cmdexit"
        Me.cmdexit.Size = New System.Drawing.Size(144, 53)
        Me.cmdexit.TabIndex = 7
        Me.cmdexit.Text = "&Exit"
        Me.cmdexit.UseVisualStyleBackColor = True
        '
        'lblscore
        '
        Me.lblscore.AutoSize = True
        Me.lblscore.Location = New System.Drawing.Point(175, 494)
        Me.lblscore.Name = "lblscore"
        Me.lblscore.Size = New System.Drawing.Size(35, 13)
        Me.lblscore.TabIndex = 8
        Me.lblscore.Text = "Score"
        '
        'lbltimetaken
        '
        Me.lbltimetaken.AutoSize = True
        Me.lbltimetaken.Location = New System.Drawing.Point(450, 494)
        Me.lbltimetaken.Name = "lbltimetaken"
        Me.lbltimetaken.Size = New System.Drawing.Size(30, 13)
        Me.lbltimetaken.TabIndex = 9
        Me.lbltimetaken.Text = "Time"
        '
        'Pictureneutral
        '
        Me.Pictureneutral.Image = CType(resources.GetObject("Pictureneutral.Image"), System.Drawing.Image)
        Me.Pictureneutral.Location = New System.Drawing.Point(270, 242)
        Me.Pictureneutral.Name = "Pictureneutral"
        Me.Pictureneutral.Size = New System.Drawing.Size(154, 144)
        Me.Pictureneutral.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pictureneutral.TabIndex = 10
        Me.Pictureneutral.TabStop = False
        Me.Pictureneutral.Visible = False
        '
        'cmdhelp
        '
        Me.cmdhelp.Location = New System.Drawing.Point(604, 638)
        Me.cmdhelp.Name = "cmdhelp"
        Me.cmdhelp.Size = New System.Drawing.Size(75, 23)
        Me.cmdhelp.TabIndex = 11
        Me.cmdhelp.Text = "&Help"
        Me.cmdhelp.UseVisualStyleBackColor = True
        '
        'frmresult
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 662)
        Me.Controls.Add(Me.cmdhelp)
        Me.Controls.Add(Me.Pictureneutral)
        Me.Controls.Add(Me.lbltimetaken)
        Me.Controls.Add(Me.lblscore)
        Me.Controls.Add(Me.cmdexit)
        Me.Controls.Add(Me.cmdshowresult)
        Me.Controls.Add(Me.txttime)
        Me.Controls.Add(Me.txtresult)
        Me.Controls.Add(Me.Picturebad)
        Me.Controls.Add(Me.Picturegood)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmresult"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmresult"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Picturegood, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Picturebad, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pictureneutral, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Picturegood As System.Windows.Forms.PictureBox
    Friend WithEvents Picturebad As System.Windows.Forms.PictureBox
    Friend WithEvents txtresult As System.Windows.Forms.TextBox
    Friend WithEvents txttime As System.Windows.Forms.TextBox
    Friend WithEvents cmdshowresult As System.Windows.Forms.Button
    Friend WithEvents cmdexit As System.Windows.Forms.Button
    Friend WithEvents lblscore As System.Windows.Forms.Label
    Friend WithEvents lbltimetaken As System.Windows.Forms.Label
    Friend WithEvents Pictureneutral As System.Windows.Forms.PictureBox
    Friend WithEvents cmdhelp As System.Windows.Forms.Button
End Class
