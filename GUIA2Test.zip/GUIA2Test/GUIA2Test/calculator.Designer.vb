﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class calculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(calculator))
        Me.btn1 = New System.Windows.Forms.Button
        Me.btn2 = New System.Windows.Forms.Button
        Me.btn3 = New System.Windows.Forms.Button
        Me.btn4 = New System.Windows.Forms.Button
        Me.btn5 = New System.Windows.Forms.Button
        Me.btn6 = New System.Windows.Forms.Button
        Me.btn7 = New System.Windows.Forms.Button
        Me.btn8 = New System.Windows.Forms.Button
        Me.btn9 = New System.Windows.Forms.Button
        Me.btn0 = New System.Windows.Forms.Button
        Me.cmdminus = New System.Windows.Forms.Button
        Me.cmdplus = New System.Windows.Forms.Button
        Me.cmddot = New System.Windows.Forms.Button
        Me.cmdexit = New System.Windows.Forms.Button
        Me.cmdequals = New System.Windows.Forms.Button
        Me.cmdclear = New System.Windows.Forms.Button
        Me.txtdisplay = New System.Windows.Forms.TextBox
        Me.txtresult = New System.Windows.Forms.TextBox
        Me.lblresult = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdmultiply = New System.Windows.Forms.Button
        Me.cmddivide = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.cmdhelp = New System.Windows.Forms.Button
        Me.cmdsquare = New System.Windows.Forms.Button
        Me.cmdmplus = New System.Windows.Forms.Button
        Me.cmdmr = New System.Windows.Forms.Button
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(38, 240)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(47, 42)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(91, 240)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(46, 42)
        Me.btn2.TabIndex = 1
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(143, 240)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(47, 41)
        Me.btn3.TabIndex = 2
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.Location = New System.Drawing.Point(38, 287)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(47, 41)
        Me.btn4.TabIndex = 3
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.Location = New System.Drawing.Point(91, 287)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(46, 42)
        Me.btn5.TabIndex = 4
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.Location = New System.Drawing.Point(144, 287)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(46, 41)
        Me.btn6.TabIndex = 5
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.Location = New System.Drawing.Point(38, 335)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(47, 40)
        Me.btn7.TabIndex = 6
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.Location = New System.Drawing.Point(91, 335)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(46, 40)
        Me.btn8.TabIndex = 7
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.Location = New System.Drawing.Point(143, 335)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(47, 40)
        Me.btn9.TabIndex = 8
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn0.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.Location = New System.Drawing.Point(91, 381)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(46, 38)
        Me.btn0.TabIndex = 9
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'cmdminus
        '
        Me.cmdminus.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdminus.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdminus.Location = New System.Drawing.Point(229, 303)
        Me.cmdminus.Name = "cmdminus"
        Me.cmdminus.Size = New System.Drawing.Size(47, 97)
        Me.cmdminus.TabIndex = 10
        Me.cmdminus.Text = "-"
        Me.cmdminus.UseVisualStyleBackColor = False
        '
        'cmdplus
        '
        Me.cmdplus.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdplus.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdplus.Location = New System.Drawing.Point(282, 303)
        Me.cmdplus.Name = "cmdplus"
        Me.cmdplus.Size = New System.Drawing.Size(47, 97)
        Me.cmdplus.TabIndex = 11
        Me.cmdplus.Text = "+"
        Me.cmdplus.UseVisualStyleBackColor = False
        '
        'cmddot
        '
        Me.cmddot.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmddot.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmddot.Location = New System.Drawing.Point(441, 303)
        Me.cmddot.Name = "cmddot"
        Me.cmddot.Size = New System.Drawing.Size(47, 96)
        Me.cmddot.TabIndex = 12
        Me.cmddot.Text = "."
        Me.cmddot.UseVisualStyleBackColor = False
        '
        'cmdexit
        '
        Me.cmdexit.BackColor = System.Drawing.Color.SeaGreen
        Me.cmdexit.Location = New System.Drawing.Point(229, 421)
        Me.cmdexit.Name = "cmdexit"
        Me.cmdexit.Size = New System.Drawing.Size(128, 51)
        Me.cmdexit.TabIndex = 13
        Me.cmdexit.Text = "&Exit"
        Me.cmdexit.UseVisualStyleBackColor = False
        '
        'cmdequals
        '
        Me.cmdequals.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdequals.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdequals.Location = New System.Drawing.Point(282, 237)
        Me.cmdequals.Name = "cmdequals"
        Me.cmdequals.Size = New System.Drawing.Size(100, 59)
        Me.cmdequals.TabIndex = 15
        Me.cmdequals.Text = "="
        Me.cmdequals.UseVisualStyleBackColor = False
        '
        'cmdclear
        '
        Me.cmdclear.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdclear.Location = New System.Drawing.Point(388, 237)
        Me.cmdclear.Name = "cmdclear"
        Me.cmdclear.Size = New System.Drawing.Size(99, 58)
        Me.cmdclear.TabIndex = 16
        Me.cmdclear.Text = "&Clear"
        Me.cmdclear.UseVisualStyleBackColor = False
        '
        'txtdisplay
        '
        Me.txtdisplay.Location = New System.Drawing.Point(57, 164)
        Me.txtdisplay.Name = "txtdisplay"
        Me.txtdisplay.Size = New System.Drawing.Size(228, 20)
        Me.txtdisplay.TabIndex = 17
        '
        'txtresult
        '
        Me.txtresult.Location = New System.Drawing.Point(342, 164)
        Me.txtresult.Name = "txtresult"
        Me.txtresult.Size = New System.Drawing.Size(152, 20)
        Me.txtresult.TabIndex = 18
        '
        'lblresult
        '
        Me.lblresult.AutoSize = True
        Me.lblresult.Location = New System.Drawing.Point(389, 148)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(37, 13)
        Me.lblresult.TabIndex = 19
        Me.lblresult.Text = "Result"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(304, 167)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "..."
        '
        'cmdmultiply
        '
        Me.cmdmultiply.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdmultiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdmultiply.Location = New System.Drawing.Point(335, 302)
        Me.cmdmultiply.Name = "cmdmultiply"
        Me.cmdmultiply.Size = New System.Drawing.Size(47, 98)
        Me.cmdmultiply.TabIndex = 21
        Me.cmdmultiply.Text = "*"
        Me.cmdmultiply.UseVisualStyleBackColor = False
        '
        'cmddivide
        '
        Me.cmddivide.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmddivide.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmddivide.Location = New System.Drawing.Point(388, 302)
        Me.cmddivide.Name = "cmddivide"
        Me.cmddivide.Size = New System.Drawing.Size(47, 97)
        Me.cmddivide.TabIndex = 22
        Me.cmddivide.Text = "/"
        Me.cmddivide.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(5, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(584, 108)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'cmdhelp
        '
        Me.cmdhelp.BackColor = System.Drawing.Color.LightSteelBlue
        Me.cmdhelp.Location = New System.Drawing.Point(514, 449)
        Me.cmdhelp.Name = "cmdhelp"
        Me.cmdhelp.Size = New System.Drawing.Size(75, 23)
        Me.cmdhelp.TabIndex = 24
        Me.cmdhelp.Text = "&Help"
        Me.cmdhelp.UseVisualStyleBackColor = False
        '
        'cmdsquare
        '
        Me.cmdsquare.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdsquare.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdsquare.Location = New System.Drawing.Point(494, 303)
        Me.cmdsquare.Name = "cmdsquare"
        Me.cmdsquare.Size = New System.Drawing.Size(48, 96)
        Me.cmdsquare.TabIndex = 25
        Me.cmdsquare.Text = "√"
        Me.cmdsquare.UseVisualStyleBackColor = False
        '
        'cmdmplus
        '
        Me.cmdmplus.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdmplus.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdmplus.Location = New System.Drawing.Point(231, 237)
        Me.cmdmplus.Name = "cmdmplus"
        Me.cmdmplus.Size = New System.Drawing.Size(45, 58)
        Me.cmdmplus.TabIndex = 26
        Me.cmdmplus.Text = "M+"
        Me.cmdmplus.UseVisualStyleBackColor = False
        '
        'cmdmr
        '
        Me.cmdmr.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdmr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdmr.Location = New System.Drawing.Point(493, 237)
        Me.cmdmr.Name = "cmdmr"
        Me.cmdmr.Size = New System.Drawing.Size(49, 57)
        Me.cmdmr.TabIndex = 27
        Me.cmdmr.Text = "MR"
        Me.cmdmr.UseVisualStyleBackColor = False
        '
        'calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(601, 484)
        Me.Controls.Add(Me.cmdmr)
        Me.Controls.Add(Me.cmdmplus)
        Me.Controls.Add(Me.cmdsquare)
        Me.Controls.Add(Me.cmdhelp)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cmddivide)
        Me.Controls.Add(Me.cmdmultiply)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblresult)
        Me.Controls.Add(Me.txtresult)
        Me.Controls.Add(Me.txtdisplay)
        Me.Controls.Add(Me.cmdclear)
        Me.Controls.Add(Me.cmdequals)
        Me.Controls.Add(Me.cmdexit)
        Me.Controls.Add(Me.cmddot)
        Me.Controls.Add(Me.cmdplus)
        Me.Controls.Add(Me.cmdminus)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Name = "calculator"
        Me.Text = "calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn5 As System.Windows.Forms.Button
    Friend WithEvents btn6 As System.Windows.Forms.Button
    Friend WithEvents btn7 As System.Windows.Forms.Button
    Friend WithEvents btn8 As System.Windows.Forms.Button
    Friend WithEvents btn9 As System.Windows.Forms.Button
    Friend WithEvents btn0 As System.Windows.Forms.Button
    Friend WithEvents cmdminus As System.Windows.Forms.Button
    Friend WithEvents cmdplus As System.Windows.Forms.Button
    Friend WithEvents cmddot As System.Windows.Forms.Button
    Friend WithEvents cmdexit As System.Windows.Forms.Button
    Friend WithEvents cmdequals As System.Windows.Forms.Button
    Friend WithEvents cmdclear As System.Windows.Forms.Button
    Friend WithEvents txtdisplay As System.Windows.Forms.TextBox
    Friend WithEvents txtresult As System.Windows.Forms.TextBox
    Friend WithEvents lblresult As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdmultiply As System.Windows.Forms.Button
    Friend WithEvents cmddivide As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents cmdhelp As System.Windows.Forms.Button
    Friend WithEvents cmdsquare As System.Windows.Forms.Button
    Friend WithEvents cmdmplus As System.Windows.Forms.Button
    Friend WithEvents cmdmr As System.Windows.Forms.Button
End Class
