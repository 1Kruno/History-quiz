﻿Public Class frmmenu
    ' user will be able to pick 3 options'
    'first option is to take a test'
    'second option is to use calculator'
    'third option is to exit'
    'user can also click on the help button to get some clarification'
    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        On Error Resume Next
        Me.Close()

    End Sub

    Private Sub cmdcalc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdcalc.Click
        On Error Resume Next
        calculator.Show()
        Me.Close()
    End Sub

    Private Sub cmdtest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdtest.Click
        On Error Resume Next
        q1.Show()
        Me.Hide()

    End Sub

    Private Sub cmdhelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhelp.Click
        On Error Resume Next
        frmhelp.Show()

    End Sub

    Private Sub frmmenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class