﻿Public Class frmlogin
    Dim user_name1 As String
    Dim password1 As String
    Dim counter As Byte
    Dim user_name2 As String
    Dim password2 As String
    Dim file_password As String
    Dim user_password As String

    'this form has 2 authorised users-tester and student'
    'both have the same password'
    '"tester" has an option to see all correct answers'
    'on successfull login user will get a message "welcome"'
    Private Sub frmlogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim C As Object
        cmbusers.Items.Add("tester")
        cmbusers.Items.Add("STUDENT")
        FileOpen(5, My.Application.Info.DirectoryPath & "\validpasswords.DAT", OpenMode.Input)
        Do Until EOF(5)
            counter = counter + 1
            Input(5, user_name1)
            Input(5, password1)
            Input(5, user_name2)
            Input(5, password2)
        Loop
        FileClose(5)


    End Sub

    Private Sub cmbusers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbusers.SelectedIndexChanged
        user = cmbusers.Text
        txtpassword.Focus()

    End Sub

    Private Sub cmdlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdlogin.Click
        On Error Resume Next
        user_password = txtpassword.Text
        If user = user_name1 And user_password = password1 Then
            MsgBox("Welcome!")
            frmmenu.Show()
            Me.Hide()
        ElseIf user = user_name2 And user_password = password2 Then
            MsgBox("Welcome!")
            frmmenu.Show()
            Me.Hide()



        Else
            MsgBox("Invalid username and/or password.Please try again!")



        End If
    End Sub

    Private Sub cmdexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdexit.Click
        On Error Resume Next
        Me.Close()



    End Sub

    Private Sub cmdhelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdhelp.Click
        frmhelp.Show()

    End Sub

    Private Sub red_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles red.CheckedChanged
        Me.BackColor = Color.Red

    End Sub

    Private Sub blue_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blue.CheckedChanged
        Me.BackColor = Color.Blue

    End Sub
End Class